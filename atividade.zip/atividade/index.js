
//index.js
const logger = require('./logger');

const obj = { name: 'nome' }
//const obj = undefined; //descomente essa linha para provocar o erro

try {
    console.log(obj.name);
    logger.info('Bom dia flor do dia');
}
catch (error) {
    logger.error(error);
}
